# Guiné Sports — servidor + frontend

## 1. Instalar
Requer Node.js 20+.

    npm install

## 2. Configurar a chave
Copie `.env.example` para `.env` e coloque sua NOVA chave:

    API_FOOTBALL_KEY=sua_nova_chave

Nunca coloque a chave dentro de `public/`.

## 3. Executar

    npm start

Abra no navegador:
http://localhost:3000

## Endpoints
GET /api/live
GET /api/fixtures?date=YYYY-MM-DD
GET /api/events/:id
GET /api/standings?league=ID&season=YYYY
GET /api/leagues

O frontend atualiza a tela de jogos ao vivo a cada 30 segundos. A chave permanece no servidor.
